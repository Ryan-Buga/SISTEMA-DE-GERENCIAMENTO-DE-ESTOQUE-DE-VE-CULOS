package com.concessionaria.estoque.controller;

import com.concessionaria.estoque.dto.Dtos.VeiculoAtualizacao;
import com.concessionaria.estoque.dto.Dtos.VeiculoRequest;
import com.concessionaria.estoque.dto.Dtos.VeiculoResponse;
import com.concessionaria.estoque.model.StatusVeiculo;
import com.concessionaria.estoque.service.VeiculoService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/veiculos")
public class VeiculoController {

    private final VeiculoService service;

    public VeiculoController(VeiculoService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<VeiculoResponse> cadastrar(@Valid @RequestBody VeiculoRequest req) {
        VeiculoResponse criado = service.cadastrar(req);
        return ResponseEntity.created(URI.create("/api/veiculos/" + criado.id())).body(criado);
    }

    @GetMapping
    public List<VeiculoResponse> listar(@RequestParam(required = false) String marca,
                                        @RequestParam(required = false) String modelo,
                                        @RequestParam(required = false) BigDecimal precoMin,
                                        @RequestParam(required = false) BigDecimal precoMax,
                                        @RequestParam(required = false) Integer ano,
                                        @RequestParam(required = false) StatusVeiculo status) {
        return service.buscar(marca, modelo, precoMin, precoMax, ano, status);
    }

    @GetMapping("/{id}")
    public VeiculoResponse buscar(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PatchMapping("/{id}")
    public VeiculoResponse atualizar(@PathVariable Long id, @Valid @RequestBody VeiculoAtualizacao dados) {
        return service.atualizar(id, dados);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> remover(@PathVariable Long id) {
        service.remover(id);
        return ResponseEntity.noContent().build();
    }
}
