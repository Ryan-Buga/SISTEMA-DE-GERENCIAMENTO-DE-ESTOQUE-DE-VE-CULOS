package com.concessionaria.estoque.controller;

import com.concessionaria.estoque.dto.Dtos.MarcaRequest;
import com.concessionaria.estoque.dto.Dtos.MarcaResponse;
import com.concessionaria.estoque.dto.Dtos.ModeloRequest;
import com.concessionaria.estoque.dto.Dtos.ModeloResponse;
import com.concessionaria.estoque.service.CatalogoService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api")
public class CatalogoController {

    private final CatalogoService service;

    public CatalogoController(CatalogoService service) {
        this.service = service;
    }

    @PostMapping("/marcas")
    public ResponseEntity<MarcaResponse> criarMarca(@Valid @RequestBody MarcaRequest req) {
        MarcaResponse criada = service.criarMarca(req);
        return ResponseEntity.created(URI.create("/api/marcas/" + criada.id())).body(criada);
    }

    @GetMapping("/marcas")
    public List<MarcaResponse> listarMarcas() {
        return service.listarMarcas();
    }

    @PostMapping("/modelos")
    public ResponseEntity<ModeloResponse> criarModelo(@Valid @RequestBody ModeloRequest req) {
        ModeloResponse criado = service.criarModelo(req);
        return ResponseEntity.created(URI.create("/api/modelos/" + criado.id())).body(criado);
    }

    @GetMapping("/modelos")
    public List<ModeloResponse> listarModelos(@RequestParam(required = false) Long marcaId) {
        return service.listarModelos(marcaId);
    }
}
