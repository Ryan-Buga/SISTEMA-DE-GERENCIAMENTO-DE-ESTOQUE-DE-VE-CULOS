package com.concessionaria.estoque.service;

import com.concessionaria.estoque.dto.Dtos.MarcaRequest;
import com.concessionaria.estoque.dto.Dtos.MarcaResponse;
import com.concessionaria.estoque.dto.Dtos.ModeloRequest;
import com.concessionaria.estoque.dto.Dtos.ModeloResponse;
import com.concessionaria.estoque.exception.RecursoNaoEncontradoException;
import com.concessionaria.estoque.model.Marca;
import com.concessionaria.estoque.model.Modelo;
import com.concessionaria.estoque.repository.MarcaRepository;
import com.concessionaria.estoque.repository.ModeloRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/** Cadastro de marcas e modelos. */
@Service
public class CatalogoService {

    private final MarcaRepository marcas;
    private final ModeloRepository modelos;

    public CatalogoService(MarcaRepository marcas, ModeloRepository modelos) {
        this.marcas = marcas;
        this.modelos = modelos;
    }

    @Transactional
    public MarcaResponse criarMarca(MarcaRequest req) {
        return MarcaResponse.de(marcas.save(new Marca(req.nome().trim())));
    }

    @Transactional(readOnly = true)
    public List<MarcaResponse> listarMarcas() {
        return marcas.findAll(Sort.by("nome")).stream().map(MarcaResponse::de).toList();
    }

    @Transactional
    public ModeloResponse criarModelo(ModeloRequest req) {
        Marca marca = marcas.findById(req.marcaId())
                .orElseThrow(() -> new RecursoNaoEncontradoException("Marca", req.marcaId()));
        return ModeloResponse.de(modelos.save(new Modelo(req.nome().trim(), marca)));
    }

    @Transactional(readOnly = true)
    public List<ModeloResponse> listarModelos(Long marcaId) {
        List<Modelo> lista = marcaId == null ? modelos.findAll() : modelos.findByMarcaId(marcaId);
        return lista.stream().map(ModeloResponse::de).toList();
    }
}
