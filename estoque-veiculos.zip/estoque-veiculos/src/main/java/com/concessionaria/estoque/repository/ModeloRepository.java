package com.concessionaria.estoque.repository;

import com.concessionaria.estoque.model.Modelo;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ModeloRepository extends JpaRepository<Modelo, Long> {

    @Override
    @EntityGraph(attributePaths = "marca")
    List<Modelo> findAll();

    @EntityGraph(attributePaths = "marca")
    List<Modelo> findByMarcaId(Long marcaId);
}
