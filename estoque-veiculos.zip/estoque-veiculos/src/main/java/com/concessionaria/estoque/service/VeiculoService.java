package com.concessionaria.estoque.service;

import com.concessionaria.estoque.dto.Dtos.VeiculoAtualizacao;
import com.concessionaria.estoque.dto.Dtos.VeiculoRequest;
import com.concessionaria.estoque.dto.Dtos.VeiculoResponse;
import com.concessionaria.estoque.exception.RecursoNaoEncontradoException;
import com.concessionaria.estoque.model.Modelo;
import com.concessionaria.estoque.model.StatusVeiculo;
import com.concessionaria.estoque.model.Veiculo;
import com.concessionaria.estoque.repository.ModeloRepository;
import com.concessionaria.estoque.repository.VeiculoRepository;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/** Regras de negócio do estoque de veículos (CRUD + filtros). */
@Service
public class VeiculoService {

    private final VeiculoRepository veiculos;
    private final ModeloRepository modelos;

    public VeiculoService(VeiculoRepository veiculos, ModeloRepository modelos) {
        this.veiculos = veiculos;
        this.modelos = modelos;
    }

    @Transactional
    public VeiculoResponse cadastrar(VeiculoRequest req) {
        Modelo modelo = modelos.findById(req.modeloId())
                .orElseThrow(() -> new RecursoNaoEncontradoException("Modelo", req.modeloId()));
        StatusVeiculo status = req.status() != null ? req.status() : StatusVeiculo.DISPONIVEL;
        Veiculo veiculo = new Veiculo(modelo, req.anoFabricacao(), req.cor().trim(),
                req.preco(), req.quilometragem(), status);
        return VeiculoResponse.de(veiculos.save(veiculo));
    }

    @Transactional(readOnly = true)
    public VeiculoResponse buscarPorId(Long id) {
        return VeiculoResponse.de(entidade(id));
    }

    /** Consulta com filtros opcionais; filtros nulos são ignorados. */
    @Transactional(readOnly = true)
    public List<VeiculoResponse> buscar(String marca, String modelo, BigDecimal precoMin,
                                        BigDecimal precoMax, Integer ano, StatusVeiculo status) {
        Specification<Veiculo> filtro = (root, query, cb) -> {
            List<Predicate> ps = new ArrayList<>();
            if (marca != null && !marca.isBlank()) {
                ps.add(cb.like(cb.lower(root.get("modelo").get("marca").<String>get("nome")),
                        "%" + marca.trim().toLowerCase() + "%"));
            }
            if (modelo != null && !modelo.isBlank()) {
                ps.add(cb.like(cb.lower(root.get("modelo").<String>get("nome")),
                        "%" + modelo.trim().toLowerCase() + "%"));
            }
            if (precoMin != null) ps.add(cb.greaterThanOrEqualTo(root.<BigDecimal>get("preco"), precoMin));
            if (precoMax != null) ps.add(cb.lessThanOrEqualTo(root.<BigDecimal>get("preco"), precoMax));
            if (ano != null) ps.add(cb.equal(root.get("anoFabricacao"), ano));
            if (status != null) ps.add(cb.equal(root.get("status"), status));
            return cb.and(ps.toArray(new Predicate[0]));
        };
        return veiculos.findAll(filtro, Sort.by(Sort.Direction.DESC, "id"))
                .stream().map(VeiculoResponse::de).toList();
    }

    @Transactional
    public VeiculoResponse atualizar(Long id, VeiculoAtualizacao dados) {
        Veiculo veiculo = entidade(id);
        veiculo.atualizar(dados.preco(), dados.quilometragem(), dados.status());
        return VeiculoResponse.de(veiculo);
    }

    @Transactional
    public void remover(Long id) {
        veiculos.delete(entidade(id));
    }

    private Veiculo entidade(Long id) {
        return veiculos.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Veículo", id));
    }
}
