package com.concessionaria.estoque.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "marca",
        uniqueConstraints = @UniqueConstraint(name = "uk_marca_nome", columnNames = "nome"))
public class Marca extends EntidadeBase {

    @Column(nullable = false, length = 60)
    private String nome;

    protected Marca() { }

    public Marca(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}
