package com.concessionaria.estoque.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.math.BigDecimal;

/** A marca do veículo é obtida pelo modelo (marca → modelo → veículo). */
@Entity
@Table(name = "veiculo", indexes = {
        @Index(name = "idx_veiculo_status", columnList = "status"),
        @Index(name = "idx_veiculo_preco", columnList = "preco"),
        @Index(name = "idx_veiculo_ano", columnList = "ano_fabricacao")
})
public class Veiculo extends EntidadeBase {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "modelo_id")
    private Modelo modelo;

    @Column(name = "ano_fabricacao", nullable = false)
    private int anoFabricacao;

    @Column(nullable = false, length = 30)
    private String cor;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal preco;

    @Column(nullable = false)
    private int quilometragem;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private StatusVeiculo status;

    protected Veiculo() { }

    public Veiculo(Modelo modelo, int anoFabricacao, String cor, BigDecimal preco,
                   int quilometragem, StatusVeiculo status) {
        this.modelo = modelo;
        this.anoFabricacao = anoFabricacao;
        this.cor = cor;
        this.preco = preco;
        this.quilometragem = quilometragem;
        this.status = status;
    }

    /** Atualiza apenas os campos informados (preço, quilometragem e status). */
    public void atualizar(BigDecimal preco, Integer quilometragem, StatusVeiculo status) {
        if (preco != null) this.preco = preco;
        if (quilometragem != null) this.quilometragem = quilometragem;
        if (status != null) this.status = status;
    }

    public Modelo getModelo() { return modelo; }
    public int getAnoFabricacao() { return anoFabricacao; }
    public String getCor() { return cor; }
    public BigDecimal getPreco() { return preco; }
    public int getQuilometragem() { return quilometragem; }
    public StatusVeiculo getStatus() { return status; }
}
