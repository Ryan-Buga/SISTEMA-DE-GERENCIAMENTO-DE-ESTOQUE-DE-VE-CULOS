package com.concessionaria.estoque.repository;

import com.concessionaria.estoque.model.Veiculo;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;

public interface VeiculoRepository extends JpaRepository<Veiculo, Long>, JpaSpecificationExecutor<Veiculo> {

    /** Carrega modelo e marca na mesma consulta (evita N+1 nas listagens filtradas). */
    @Override
    @EntityGraph(attributePaths = {"modelo", "modelo.marca"})
    List<Veiculo> findAll(Specification<Veiculo> spec, Sort sort);
}
