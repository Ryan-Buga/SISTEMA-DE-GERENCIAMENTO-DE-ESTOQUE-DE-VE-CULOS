package com.concessionaria.estoque.dto;

import com.concessionaria.estoque.model.Marca;
import com.concessionaria.estoque.model.Modelo;
import com.concessionaria.estoque.model.StatusVeiculo;
import com.concessionaria.estoque.model.Veiculo;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

/** Objetos de entrada e saída da API (a entidade nunca é exposta diretamente). */
public final class Dtos {

    private Dtos() { }

    public record MarcaRequest(
            @NotBlank(message = "O nome da marca é obrigatório") @Size(max = 60) String nome) { }

    public record MarcaResponse(Long id, String nome) {
        public static MarcaResponse de(Marca m) {
            return new MarcaResponse(m.getId(), m.getNome());
        }
    }

    public record ModeloRequest(
            @NotBlank(message = "O nome do modelo é obrigatório") @Size(max = 80) String nome,
            @NotNull(message = "A marca é obrigatória") Long marcaId) { }

    public record ModeloResponse(Long id, String nome, Long marcaId, String marca) {
        public static ModeloResponse de(Modelo m) {
            return new ModeloResponse(m.getId(), m.getNome(), m.getMarca().getId(), m.getMarca().getNome());
        }
    }

    public record VeiculoRequest(
            @NotNull(message = "O modelo é obrigatório") Long modeloId,
            @NotNull(message = "O ano de fabricação é obrigatório")
            @Min(value = 1900, message = "Ano inválido") @Max(value = 2100, message = "Ano inválido") Integer anoFabricacao,
            @NotBlank(message = "A cor é obrigatória") @Size(max = 30) String cor,
            @NotNull(message = "O preço é obrigatório")
            @DecimalMin(value = "0.0", message = "O preço não pode ser negativo") BigDecimal preco,
            @NotNull(message = "A quilometragem é obrigatória")
            @Min(value = 0, message = "A quilometragem não pode ser negativa") Integer quilometragem,
            StatusVeiculo status) { }

    /** Campos editáveis de um veículo existente; os que vierem nulos permanecem como estão. */
    public record VeiculoAtualizacao(
            @DecimalMin(value = "0.0", message = "O preço não pode ser negativo") BigDecimal preco,
            @Min(value = 0, message = "A quilometragem não pode ser negativa") Integer quilometragem,
            StatusVeiculo status) { }

    public record VeiculoResponse(Long id, Long modeloId, String marca, String modelo, Integer anoFabricacao,
                                  String cor, BigDecimal preco, Integer quilometragem, StatusVeiculo status) {
        public static VeiculoResponse de(Veiculo v) {
            Modelo m = v.getModelo();
            return new VeiculoResponse(v.getId(), m.getId(), m.getMarca().getNome(), m.getNome(),
                    v.getAnoFabricacao(), v.getCor(), v.getPreco(), v.getQuilometragem(), v.getStatus());
        }
    }
}
