# Estoque de veículos

Sistema CRUD orientado a objetos para gestão de estoque de veículos de uma concessionária.
Backend em **Java 17 + Spring Boot 3 (API REST)**, banco **MySQL 8** e um frontend simples (HTML/JS) servido pelo próprio Spring.

## Como executar

1. Tenha instalados Java 17+, Maven e MySQL 8.
2. Ajuste `spring.datasource.username` e `spring.datasource.password` em `src/main/resources/application.properties`.
3. Rode:

   ```bash
   mvn spring-boot:run
   ```

4. Abra http://localhost:8080 (listagem e filtros) ou use a API em `/api`.

As tabelas são criadas automaticamente na primeira execução. O arquivo `database/schema.sql` traz o modelo físico completo e dados de exemplo; rode-o no MySQL antes (ou depois) se quiser os dados de teste.

## Arquitetura

```
controller → service → repository → MySQL
     └── dto (entrada/saída)      model (Marca, Modelo, Veiculo, StatusVeiculo)
```

Relacionamento: `Marca 1 — N Modelo 1 — N Veiculo`. A marca de um veículo é obtida pelo seu modelo.

## Endpoints

| Método | Rota | Descrição |
|---|---|---|
| POST | `/api/marcas` | Cadastra marca |
| GET | `/api/marcas` | Lista marcas |
| POST | `/api/modelos` | Cadastra modelo (informa `marcaId`) |
| GET | `/api/modelos?marcaId=` | Lista modelos (filtro opcional por marca) |
| POST | `/api/veiculos` | Cadastra veículo |
| GET | `/api/veiculos` | Lista com filtros: `marca`, `modelo`, `precoMin`, `precoMax`, `ano`, `status` |
| GET | `/api/veiculos/{id}` | Consulta um veículo |
| PATCH | `/api/veiculos/{id}` | Atualiza `preco`, `quilometragem` e/ou `status` |
| DELETE | `/api/veiculos/{id}` | Remove o veículo |

`status`: `DISPONIVEL`, `RESERVADO`, `VENDIDO` ou `DESCONTINUADO`.

## Exemplos (curl)

```bash
curl -X POST localhost:8080/api/marcas  -H "Content-Type: application/json" -d '{"nome":"Toyota"}'
curl -X POST localhost:8080/api/modelos -H "Content-Type: application/json" -d '{"nome":"Corolla","marcaId":1}'
curl -X POST localhost:8080/api/veiculos -H "Content-Type: application/json" \
  -d '{"modeloId":1,"anoFabricacao":2022,"cor":"Prata","preco":128900.00,"quilometragem":25000}'

curl "localhost:8080/api/veiculos?marca=toyota&precoMax=150000&status=DISPONIVEL"

curl -X PATCH localhost:8080/api/veiculos/1 -H "Content-Type: application/json" \
  -d '{"preco":125000.00,"quilometragem":26000,"status":"RESERVADO"}'

curl -X DELETE localhost:8080/api/veiculos/1
```

## Erros

Respostas no formato `ProblemDetail`: `400` (dados inválidos, com os campos), `404` (id inexistente) e `409` (marca ou modelo duplicado).
