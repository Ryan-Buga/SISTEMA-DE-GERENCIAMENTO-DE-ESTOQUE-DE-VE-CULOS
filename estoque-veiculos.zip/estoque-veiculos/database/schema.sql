-- Modelo físico (MySQL 8) do estoque de veículos: marca 1 --- N modelo 1 --- N veiculo
CREATE DATABASE IF NOT EXISTS estoque_veiculos CHARACTER SET utf8mb4;
USE estoque_veiculos;

CREATE TABLE IF NOT EXISTS marca (
    id   BIGINT      NOT NULL AUTO_INCREMENT,
    nome VARCHAR(60) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_marca_nome UNIQUE (nome)
);

CREATE TABLE IF NOT EXISTS modelo (
    id       BIGINT      NOT NULL AUTO_INCREMENT,
    nome     VARCHAR(80) NOT NULL,
    marca_id BIGINT      NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_modelo_marca_nome UNIQUE (marca_id, nome),
    CONSTRAINT fk_modelo_marca FOREIGN KEY (marca_id) REFERENCES marca (id)
);

CREATE TABLE IF NOT EXISTS veiculo (
    id             BIGINT        NOT NULL AUTO_INCREMENT,
    modelo_id      BIGINT        NOT NULL,
    ano_fabricacao INT           NOT NULL,
    cor            VARCHAR(30)   NOT NULL,
    preco          DECIMAL(12,2) NOT NULL,
    quilometragem  INT           NOT NULL,
    status         ENUM('DISPONIVEL','RESERVADO','VENDIDO','DESCONTINUADO') NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_veiculo_modelo FOREIGN KEY (modelo_id) REFERENCES modelo (id),
    INDEX idx_veiculo_status (status),
    INDEX idx_veiculo_preco (preco),
    INDEX idx_veiculo_ano (ano_fabricacao)
);

-- Dados de exemplo (execute uma única vez)
INSERT IGNORE INTO marca (nome) VALUES ('Toyota'), ('Honda'), ('Volkswagen'), ('Fiat');

INSERT INTO modelo (nome, marca_id) SELECT 'Corolla', id FROM marca WHERE nome = 'Toyota';
INSERT INTO modelo (nome, marca_id) SELECT 'Civic',   id FROM marca WHERE nome = 'Honda';
INSERT INTO modelo (nome, marca_id) SELECT 'Polo',    id FROM marca WHERE nome = 'Volkswagen';
INSERT INTO modelo (nome, marca_id) SELECT 'Argo',    id FROM marca WHERE nome = 'Fiat';

INSERT INTO veiculo (modelo_id, ano_fabricacao, cor, preco, quilometragem, status)
SELECT id, 2022, 'Prata',  128900.00, 25000, 'DISPONIVEL' FROM modelo WHERE nome = 'Corolla';
INSERT INTO veiculo (modelo_id, ano_fabricacao, cor, preco, quilometragem, status)
SELECT id, 2020, 'Preto',  112500.00, 48000, 'DISPONIVEL' FROM modelo WHERE nome = 'Civic';
INSERT INTO veiculo (modelo_id, ano_fabricacao, cor, preco, quilometragem, status)
SELECT id, 2023, 'Branco',  94990.00, 12000, 'RESERVADO'  FROM modelo WHERE nome = 'Polo';
INSERT INTO veiculo (modelo_id, ano_fabricacao, cor, preco, quilometragem, status)
SELECT id, 2019, 'Vermelho', 58900.00, 63000, 'VENDIDO'   FROM modelo WHERE nome = 'Argo';
